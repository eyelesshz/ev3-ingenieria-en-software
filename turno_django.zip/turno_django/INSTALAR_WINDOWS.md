# TURNO · Backend Django (prototipo académico)

## Qué incluye

- Django para administrar perfiles, equipos, solicitudes, entregas, devoluciones e incidencias.
- Persistencia inicial con SQLite; configuración opcional para PostgreSQL.
- Pantallas de prueba del backend y copias sin cambios de tu frontend original en `prototipo_original/`.
- Usuarios ficticios de demostración, historial y pruebas automatizadas.

**Importante:** El diseño de tu web original NO está conectado todavía con estas vistas Django. Es el siguiente paso. No publicar este entorno tal cual en Internet.

## Instalación (Windows 11, PowerShell en VS Code)

1. Descomprime el ZIP en una carpeta, por ejemplo `Escritorio/turno_django`.
2. Abre la carpeta `turno_django` con **Archivo > Abrir carpeta** en VS Code.
3. Abre **Terminal > Nueva terminal**. Asegúrate de que la ruta contenga `manage.py`.
4. Ejecuta los siguientes comandos, uno por uno:

```powershell
py --version
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env
.\.venv\Scripts\python.exe manage.py makemigrations prestamos
.\.venv\Scripts\python.exe manage.py migrate
.\.venv\Scripts\python.exe manage.py cargar_demo
.\.venv\Scripts\python.exe manage.py check
.\.venv\Scripts\python.exe manage.py runserver
```

5. Abre http://127.0.0.1:8000/ y usa una cuenta `admin_demo`, `prof_demo` o `alum_demo` junto con la contraseña aleatoria que apareció al ejecutar `cargar_demo`.
6. Para detener, pulsa `Ctrl+C`. Para volver a iniciar:

```powershell
.\.venv\Scripts\python.exe manage.py runserver
```

**Nota:** usar `.venv\\Scripts\\python.exe` evita tener que cambiar la política de ejecución de PowerShell.

## Pruebas

```powershell
.\.venv\Scripts\python.exe manage.py test prestamos
```

Si modificas los modelos:

```powershell
.\.venv\Scripts\python.exe manage.py makemigrations prestamos
.\.venv\Scripts\python.exe manage.py migrate
```

## Cuentas de demostración

El comando `cargar_demo` crea `admin_demo`, `prof_demo` y `alum_demo` con contraseñas aleatorias **solo la primera vez**. Copia las contraseñas de tu terminal y no las subas a GitHub. Si quieres una cuenta administradora adicional:

```powershell
.\.venv\Scripts\python.exe manage.py createsuperuser
```

Para que un usuario nuevo sea profesor o alumno, edita/asigna su `Perfil` en `/admin/` con la cuenta administradora.

## Cambiar a PostgreSQL después (opcional)

1. Instala PostgreSQL localmente, crea una base `turno_db` y un usuario de permisos limitados.
2. Instala el controlador:

```powershell
.\.venv\Scripts\python.exe -m pip install "psycopg[binary]>=3.2,<4"
```

3. Cambia `.env` con `DB_ENGINE=postgres`, `DB_NAME=turno_db`, `DB_USER=turno`, `DB_PASSWORD=...`, etc.
4. Ejecuta `manage.py migrate`. **Los datos anteriores de SQLite no se copian automáticamente**.

## Alcance y limitaciones

- Los formularios actuales son vistas funcionales independientes de tu frontend original, no un API JSON. Una futura etapa conectará el diseño existente con Django usando plantillas o fetch/API con CSRF.
- La caducidad se procesa manualmente con `python manage.py vencer_reservas` (en producción necesitará una tarea programada).
- Las aprobaciones concurrentes requieren probarse contra PostgreSQL antes de usarse con personas reales.
- Falta documentar todas las evidencias y probar restricciones más exhaustivas.
- Este proyecto contiene herramientas de demostración; no usar información personal real ni desplegar con `DEBUG=1`.
