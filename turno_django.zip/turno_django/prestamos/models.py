from datetime import time
from django.conf import settings
from django.db import models
from django.db.models import Q
from django.utils import timezone


class Perfil(models.Model):
    ADMIN = "admin"
    PROFESOR = "prof"
    ALUMNO = "alum"
    ROLES = [(ADMIN, "Administrador"), (PROFESOR, "Profesor"), (ALUMNO, "Alumno")]
    usuario = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="perfil")
    rol = models.CharField(max_length=5, choices=ROLES, default=ALUMNO)

    def __str__(self):
        return f"{self.usuario.username} ({self.get_rol_display()})"


class Equipo(models.Model):
    CONDICIONES = [("operativo", "Operativo"), ("reparacion", "En reparación"), ("baja", "Dado de baja")]
    codigo = models.CharField(max_length=30, primary_key=True)
    nombre = models.CharField(max_length=140)
    categoria = models.CharField(max_length=80)
    condicion = models.CharField(max_length=15, choices=CONDICIONES, default="operativo")
    prestable = models.BooleanField(default=True)
    solo_profesores = models.BooleanField(default=False)
    creado = models.DateTimeField(auto_now_add=True)
    actualizado = models.DateTimeField(auto_now=True)

    @property
    def disponible_para_prestamo(self):
        return self.prestable and self.condicion == "operativo"

    def __str__(self):
        return f"{self.codigo} · {self.nombre}"


class Configuracion(models.Model):
    # Se usa una sola fila, con id=1; definir las políticas reales antes del piloto.
    id = models.PositiveSmallIntegerField(primary_key=True, default=1, editable=False)
    prestamos_habilitados = models.BooleanField(default=True)
    alumnos_habilitados = models.BooleanField(default=True)
    prioridad_docente = models.BooleanField(default=True)
    bloqueo_pendientes = models.BooleanField(default=True)
    solicitud_desde = models.TimeField(default=time(0, 0))
    solicitud_hasta = models.TimeField(default=time(23, 59))
    atencion_desde = models.TimeField(default=time(8, 0))
    atencion_hasta = models.TimeField(default=time(17, 0))
    duracion_maxima_horas = models.PositiveSmallIntegerField(default=2)

    @classmethod
    def actual(cls):
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj

    def __str__(self):
        return "Configuración del servicio"


class Solicitud(models.Model):
    PENDIENTE = "pendiente"
    APROBADA = "aprobada"
    ENTREGADA = "entregada"
    CERRADA = "cerrada"
    RECHAZADA = "rechazada"
    CANCELADA = "cancelada"
    VENCIDA = "vencida"
    ESTADOS = [(v, v.capitalize()) for v in [PENDIENTE, APROBADA, ENTREGADA, CERRADA, RECHAZADA, CANCELADA, VENCIDA]]
    equipo = models.ForeignKey(Equipo, on_delete=models.PROTECT, related_name="solicitudes")
    solicitante = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="solicitudes")
    desde = models.DateTimeField()
    hasta = models.DateTimeField()
    motivo = models.CharField(max_length=240)
    estado = models.CharField(max_length=12, choices=ESTADOS, default=PENDIENTE)
    creado = models.DateTimeField(default=timezone.now, editable=False)
    aprobado_por = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="autorizadas")
    aprobado_el = models.DateTimeField(null=True, blank=True)
    motivo_rechazo = models.CharField(max_length=240, blank=True)
    entregado_por = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="entregadas")
    entregado_el = models.DateTimeField(null=True, blank=True)
    condicion_salida = models.CharField(max_length=240, blank=True)
    recibido_por = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="recibidas")
    recibido_el = models.DateTimeField(null=True, blank=True)
    condicion_retorno = models.CharField(max_length=240, blank=True)
    incidencia_abierta = models.BooleanField(default=False)
    incidencia_detalle = models.CharField(max_length=240, blank=True)
    incidencia_resuelta_el = models.DateTimeField(null=True, blank=True)
    incidencia_resuelta_por = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="incidencias_resueltas")

    class Meta:
        ordering = ["-creado", "-id"]
        indexes = [models.Index(fields=["equipo", "estado", "desde", "hasta"])]
        constraints = [models.CheckConstraint(condition=Q(hasta__gt=models.F("desde")), name="solicitud_fechas_ordenadas")]

    @property
    def atrasada(self):
        return self.estado == self.ENTREGADA and self.hasta < timezone.now()

    def __str__(self):
        return f"#{self.pk} · {self.equipo_id} · {self.estado}"


class Movimiento(models.Model):
    solicitud = models.ForeignKey(Solicitud, on_delete=models.PROTECT, related_name="movimientos")
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL)
    accion = models.CharField(max_length=30)
    detalle = models.CharField(max_length=255, blank=True)
    fecha = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-fecha", "-pk"]

    def __str__(self):
        return f"#{self.solicitud_id} · {self.accion}"
