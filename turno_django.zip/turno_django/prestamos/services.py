"""Reglas de negocio del anteproyecto. Todas las mutaciones críticas van por estos servicios."""
from datetime import timedelta
from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone
from .models import Configuracion, Equipo, Movimiento, Perfil, Solicitud


def rol_de(usuario):
    if not usuario.is_authenticated or not usuario.is_active:
        return None
    if usuario.is_superuser:
        return Perfil.ADMIN
    try:
        perfil = usuario.perfil.rol
    except Perfil.DoesNotExist:
        return None
    # is_staff permite entrar al admin de Django, pero por sí solo NO asigna rol Turno.
    if perfil == Perfil.ADMIN:
        return Perfil.ADMIN if usuario.is_staff else None
    if perfil in (Perfil.PROFESOR, Perfil.ALUMNO) and not usuario.is_staff:
        return perfil
    return None


def exigir_admin(usuario):
    if rol_de(usuario) != Perfil.ADMIN:
        raise ValidationError("Solo un administrador puede realizar esta operación.")


def exigir_solicitante(usuario):
    if rol_de(usuario) not in [Perfil.PROFESOR, Perfil.ALUMNO]:
        raise ValidationError("Esta cuenta no tiene permisos para solicitar equipos.")


def titular_bloqueado(usuario):
    actual = timezone.now()
    return Solicitud.objects.filter(solicitante=usuario, incidencia_abierta=True).exists() or Solicitud.objects.filter(
        solicitante=usuario, estado=Solicitud.ENTREGADA, hasta__lt=actual
    ).exists()


def verificar_reglas(usuario, equipo, desde, hasta):
    cfg = Configuracion.actual()
    role = rol_de(usuario)
    exigir_solicitante(usuario)
    if not cfg.prestamos_habilitados:
        raise ValidationError("Los préstamos están deshabilitados por el colegio.")
    if role == Perfil.ALUMNO and not cfg.alumnos_habilitados:
        raise ValidationError("El colegio no habilitó solicitudes de alumnos.")
    if equipo.condicion != "operativo" or not equipo.prestable:
        raise ValidationError("El equipo está fuera de servicio o no es prestable.")
    if equipo.solo_profesores and role != Perfil.PROFESOR:
        raise ValidationError("Este equipo es exclusivo de profesores.")
    if cfg.bloqueo_pendientes and titular_bloqueado(usuario):
        raise ValidationError("Tienes un atraso o una incidencia pendiente; no puedes solicitar otro equipo.")
    local_actual = timezone.localtime()
    hora_actual = local_actual.time().replace(tzinfo=None)
    if not (cfg.solicitud_desde <= hora_actual <= cfg.solicitud_hasta):
        raise ValidationError("La ventana para enviar solicitudes está cerrada.")
    if desde <= timezone.now():
        raise ValidationError("El inicio debe ser una fecha y hora futuras.")
    if hasta <= desde:
        raise ValidationError("La hora final debe ser posterior al inicio.")
    d1, d2 = timezone.localtime(desde), timezone.localtime(hasta)
    if d1.date() != d2.date():
        raise ValidationError("Esta versión solo permite reservas dentro del mismo día.")
    if not (cfg.atencion_desde <= d1.time().replace(tzinfo=None) < cfg.atencion_hasta):
        raise ValidationError("La hora de retiro está fuera del horario de atención.")
    if not (cfg.atencion_desde < d2.time().replace(tzinfo=None) <= cfg.atencion_hasta):
        raise ValidationError("La devolución está fuera del horario de atención.")
    if hasta - desde > timedelta(hours=cfg.duracion_maxima_horas):
        raise ValidationError(f"La duración máxima es de {cfg.duracion_maxima_horas} horas.")


def registrar(solicitud, actor, accion, detalle=""):
    Movimiento.objects.create(solicitud=solicitud, actor=actor, accion=accion, detalle=detalle[:255])


@transaction.atomic
def crear_solicitud(usuario, equipo, desde, hasta, motivo):
    # El conjunto de equipos permitido por el formulario NO reemplaza la revisión del servidor.
    equipo = Equipo.objects.select_for_update().get(pk=equipo.pk)
    verificar_reglas(usuario, equipo, desde, hasta)
    if not motivo or not motivo.strip():
        raise ValidationError("Indica el motivo de la solicitud.")
    if len(motivo.strip()) > 240:
        raise ValidationError("El motivo no puede superar 240 caracteres.")
    sol = Solicitud.objects.create(equipo=equipo, solicitante=usuario,
        desde=desde, hasta=hasta, motivo=motivo.strip())
    registrar(sol, usuario, "crear", "Solicitud registrada como pendiente; no reserva el equipo.")
    return sol


@transaction.atomic
def aprobar(actor, solicitud_id):
    exigir_admin(actor)
    sol = Solicitud.objects.select_for_update().select_related("solicitante", "equipo").get(pk=solicitud_id)
    equipo = Equipo.objects.select_for_update().get(pk=sol.equipo_id)
    if sol.estado != Solicitud.PENDIENTE:
        raise ValidationError("Solo pueden aprobarse solicitudes pendientes.")
    if sol.desde <= timezone.now():
        raise ValidationError("La fecha de inicio ya pasó. Se necesita otra solicitud.")
    if not sol.solicitante.is_active or (Configuracion.actual().bloqueo_pendientes and titular_bloqueado(sol.solicitante)):
        raise ValidationError("El solicitante está inactivo o restringido.")
    if not equipo.disponible_para_prestamo:
        raise ValidationError("El equipo no está disponible para préstamo.")
    if equipo.solo_profesores and rol_de(sol.solicitante) != Perfil.PROFESOR:
        raise ValidationError("Solo un profesor puede utilizar este equipo.")
    if Solicitud.objects.filter(equipo=equipo, estado=Solicitud.ENTREGADA).exclude(pk=sol.pk).exists():
        raise ValidationError("El equipo sigue físicamente prestado; primero debe devolverse.")
    if Solicitud.objects.filter(equipo=equipo, estado=Solicitud.APROBADA,
        desde__lt=sol.hasta, hasta__gt=sol.desde).exclude(pk=sol.pk).exists():
        raise ValidationError("Ya existe una reserva aprobada superpuesta para esta unidad.")
    cfg = Configuracion.actual()
    if cfg.prioridad_docente:
        otros = Solicitud.objects.filter(equipo=equipo, estado=Solicitud.PENDIENTE,
            desde__lt=sol.hasta, hasta__gt=sol.desde).exclude(pk=sol.pk).select_related("solicitante__perfil").order_by("creado", "pk")
        mi_rol = rol_de(sol.solicitante)
        for candidato in otros:
            r = rol_de(candidato.solicitante)
            if not candidato.solicitante.is_active or (cfg.bloqueo_pendientes and titular_bloqueado(candidato.solicitante)):
                continue
            if (r == Perfil.PROFESOR and mi_rol == Perfil.ALUMNO) or (r == mi_rol and (candidato.creado, candidato.pk) < (sol.creado, sol.pk)):
                raise ValidationError("Hay una solicitud pendiente con mayor prioridad docente o antigüedad.")
    sol.estado = Solicitud.APROBADA
    sol.aprobado_por = actor
    sol.aprobado_el = timezone.now()
    sol.save(update_fields=["estado", "aprobado_por", "aprobado_el"])
    registrar(sol, actor, "aprobar", "Unidad reservada para el intervalo solicitado.")
    return sol


@transaction.atomic
def rechazar(actor, solicitud_id, motivo):
    exigir_admin(actor)
    sol = Solicitud.objects.select_for_update().get(pk=solicitud_id)
    if sol.estado != Solicitud.PENDIENTE:
        raise ValidationError("Solo se rechazan solicitudes pendientes.")
    if not motivo.strip():
        raise ValidationError("Es obligatorio indicar el motivo del rechazo.")
    if len(motivo.strip()) > 240:
        raise ValidationError("El motivo no puede superar 240 caracteres.")
    sol.estado, sol.motivo_rechazo = Solicitud.RECHAZADA, motivo.strip()
    sol.save(update_fields=["estado", "motivo_rechazo"])
    registrar(sol, actor, "rechazar", sol.motivo_rechazo)
    return sol


@transaction.atomic
def entregar(actor, solicitud_id, condicion="Sin observaciones"):
    exigir_admin(actor)
    sol = Solicitud.objects.select_for_update().get(pk=solicitud_id)
    equipo = Equipo.objects.select_for_update().get(pk=sol.equipo_id)
    if sol.estado != Solicitud.APROBADA:
        raise ValidationError("Solo se puede entregar una solicitud aprobada.")
    if sol.hasta <= timezone.now():
        raise ValidationError("Terminó el período aprobado; no puede entregarse.")
    if not equipo.disponible_para_prestamo or not sol.solicitante.is_active:
        raise ValidationError("Equipo o solicitante no disponible.")
    if Solicitud.objects.filter(equipo=equipo, estado=Solicitud.ENTREGADA).exclude(pk=sol.pk).exists():
        raise ValidationError("Ese equipo ya fue entregado y aún no ha sido devuelto.")
    if Configuracion.actual().bloqueo_pendientes and titular_bloqueado(sol.solicitante):
        raise ValidationError("El solicitante tiene una obligación pendiente.")
    sol.estado, sol.entregado_por, sol.entregado_el = Solicitud.ENTREGADA, actor, timezone.now()
    sol.condicion_salida = condicion.strip()[:240] or "Sin observaciones"
    sol.save(update_fields=["estado", "entregado_por", "entregado_el", "condicion_salida"])
    registrar(sol, actor, "entregar", sol.condicion_salida)
    return sol


@transaction.atomic
def devolver(actor, solicitud_id, condicion="Sin observaciones", incidente=""):
    exigir_admin(actor)
    sol = Solicitud.objects.select_for_update().get(pk=solicitud_id)
    if sol.estado != Solicitud.ENTREGADA:
        raise ValidationError("Solo se puede devolver un préstamo activo.")
    sol.estado, sol.recibido_por, sol.recibido_el = Solicitud.CERRADA, actor, timezone.now()
    sol.condicion_retorno = condicion.strip()[:240] or "Sin observaciones"
    sol.incidencia_detalle = incidente.strip()[:240]
    sol.incidencia_abierta = bool(sol.incidencia_detalle)
    sol.save(update_fields=["estado", "recibido_por", "recibido_el", "condicion_retorno", "incidencia_detalle", "incidencia_abierta"])
    registrar(sol, actor, "devolver", "Incidencia abierta: " + sol.incidencia_detalle if sol.incidencia_abierta else sol.condicion_retorno)
    return sol


@transaction.atomic
def resolver_incidencia(actor, solicitud_id):
    exigir_admin(actor)
    sol = Solicitud.objects.select_for_update().get(pk=solicitud_id)
    if not sol.incidencia_abierta:
        raise ValidationError("Esta solicitud no tiene incidencias abiertas.")
    sol.incidencia_abierta, sol.incidencia_resuelta_el, sol.incidencia_resuelta_por = False, timezone.now(), actor
    sol.save(update_fields=["incidencia_abierta", "incidencia_resuelta_el", "incidencia_resuelta_por"])
    registrar(sol, actor, "resolver", "Incidencia resuelta por el administrador.")
    return sol


@transaction.atomic
def cancelar(actor, solicitud_id):
    sol = Solicitud.objects.select_for_update().get(pk=solicitud_id)
    if sol.solicitante_id != actor.pk and rol_de(actor) != Perfil.ADMIN:
        raise ValidationError("No tienes permiso para cancelar esta solicitud.")
    if sol.estado not in [Solicitud.PENDIENTE, Solicitud.APROBADA]:
        raise ValidationError("Solo se pueden cancelar reservas antes de la entrega.")
    # Bloquear equipo antes de mutar, igual que en aprobar y entregar.
    Equipo.objects.select_for_update().get(pk=sol.equipo_id)
    sol.estado = Solicitud.CANCELADA
    sol.save(update_fields=["estado"])
    registrar(sol, actor, "cancelar", "Reserva liberada antes de la entrega.")
    return sol


@transaction.atomic
def dar_baja(actor, codigo):
    exigir_admin(actor)
    equipo = Equipo.objects.select_for_update().get(pk=codigo)
    if Solicitud.objects.filter(equipo=equipo, estado__in=[Solicitud.APROBADA, Solicitud.ENTREGADA]).exists():
        raise ValidationError("No se puede dar de baja un equipo con reserva o préstamo activo.")
    equipo.condicion, equipo.prestable = "baja", False
    equipo.save(update_fields=["condicion", "prestable", "actualizado"])
    return equipo


@transaction.atomic
def vencer_reservas_vencidas():
    """Llamar periódicamente desde `manage.py vencer_reservas`. No lo dispara el frontend."""
    ids = list(Solicitud.objects.filter(estado=Solicitud.APROBADA, hasta__lt=timezone.now()).values_list("id", flat=True))
    count = 0
    for pk in ids:
        sol = Solicitud.objects.select_for_update().get(pk=pk)
        Equipo.objects.select_for_update().get(pk=sol.equipo_id)
        if sol.estado == Solicitud.APROBADA and sol.hasta <= timezone.now():
            sol.estado = Solicitud.VENCIDA
            sol.save(update_fields=["estado"])
            registrar(sol, None, "vencer", "Reserva no retirada; período finalizado.")
            count += 1
    return count
