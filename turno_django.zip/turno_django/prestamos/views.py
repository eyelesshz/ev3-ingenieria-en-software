from datetime import date, datetime, time, timedelta
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction
from django.contrib.auth import get_user_model
from django.db.models import Q
from django.http import HttpResponseForbidden
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST
from django.views.decorators.cache import never_cache
from .forms import ConfiguracionForm, EquipoForm, SolicitudForm, UsuarioNuevoForm, UsuarioEditarForm, UsuarioClaveForm
from .models import Configuracion, Equipo, Movimiento, Perfil, Solicitud
from . import services


def es_admin(usuario):
    return services.rol_de(usuario) == Perfil.ADMIN


def solo_admin(request):
    return None if es_admin(request.user) else HttpResponseForbidden("Solo administradores.")


@login_required
@never_cache
def inicio(request):
    admin = es_admin(request.user)
    rol = services.rol_de(request.user)
    if rol not in (Perfil.ADMIN, Perfil.PROFESOR, Perfil.ALUMNO):
        return HttpResponseForbidden("Esta cuenta no tiene un perfil habilitado.")
    qs = Solicitud.objects.select_related("equipo", "solicitante")
    if not admin:
        qs = qs.filter(solicitante=request.user)
    equipos_visibles = Equipo.objects.all() if admin else Equipo.objects.filter(prestable=True, condicion="operativo")
    if rol == Perfil.ALUMNO:
        equipos_visibles = equipos_visibles.filter(solo_profesores=False)
    equipo_count = equipos_visibles.count()
    return render(request, "prestamos/inicio.html", {
        "admin_activo": admin, "total_equipos": equipo_count,
        "pendientes": qs.filter(estado=Solicitud.PENDIENTE).count(),
        "activos": qs.filter(estado=Solicitud.ENTREGADA).count(),
        "incidencias": qs.filter(incidencia_abierta=True).count(),
        "recientes": qs[:6],
    })


@login_required
@never_cache
def inventario(request):
    rol = services.rol_de(request.user)
    if rol not in (Perfil.ADMIN, Perfil.PROFESOR, Perfil.ALUMNO):
        return HttpResponseForbidden("Esta cuenta no tiene un perfil habilitado.")
    admin = rol == Perfil.ADMIN
    equipos = Equipo.objects.all().order_by("categoria", "nombre")
    if rol != Perfil.ADMIN:
        equipos = equipos.filter(prestable=True, condicion="operativo")
    if rol == Perfil.ALUMNO:
        equipos = equipos.filter(solo_profesores=False)
    return render(request, "prestamos/inventario.html", {"equipos": equipos, "admin_activo": admin})


@login_required
@never_cache
def editar_equipo(request, codigo=None):
    denegado = solo_admin(request)
    if denegado:
        return denegado
    equipo = get_object_or_404(Equipo, pk=codigo) if codigo else None
    form = EquipoForm(request.POST or None, instance=equipo)
    if equipo:
        form.fields["codigo"].disabled = True
    if request.method == "POST" and form.is_valid():
        if equipo and Solicitud.objects.filter(equipo=equipo, estado__in=[Solicitud.APROBADA, Solicitud.ENTREGADA]).exists():
            cambiados = set(form.changed_data)
            if cambiados & {"condicion", "prestable", "solo_profesores"}:
                form.add_error(None, "No puedes cambiar condición, préstamo ni exclusividad con reservas o entregas activas.")
            else:
                form.save()
                messages.success(request, "Equipo guardado en la base de datos.")
                return redirect("inventario")
        else:
            form.save()
            messages.success(request, "Equipo guardado en la base de datos.")
            return redirect("inventario")
    return render(request, "prestamos/formulario.html", {
        "form": form, "titulo": "Editar equipo" if equipo else "Agregar equipo", "admin_activo": True,
    })


@login_required
@require_POST
def dar_de_baja(request, codigo):
    try:
        services.dar_baja(request.user, codigo)
        messages.success(request, "Equipo dado de baja conservando su historial.")
    except (ValidationError, Equipo.DoesNotExist) as exc:
        messages.error(request, str(exc))
    return redirect("inventario")


@login_required
@never_cache
def solicitudes(request):
    rol = services.rol_de(request.user)
    if rol not in (Perfil.ADMIN, Perfil.PROFESOR, Perfil.ALUMNO):
        return HttpResponseForbidden("Esta cuenta no tiene un perfil habilitado.")
    admin = rol == Perfil.ADMIN
    qs = Solicitud.objects.select_related("equipo", "solicitante")
    if not admin:
        qs = qs.filter(solicitante=request.user)
    else:
        # Orden administrativo: solicitudes pendientes docentes antes que alumnos.
        from django.db.models import Case, IntegerField, Value, When
        qs = qs.annotate(prioridad=Case(
            When(solicitante__perfil__rol=Perfil.PROFESOR, then=Value(0)),
            default=Value(1), output_field=IntegerField(),
        )).order_by("prioridad", "creado", "pk")
    return render(request, "prestamos/solicitudes.html", {"solicitudes": qs, "admin_activo": admin})


@login_required
@never_cache
def nueva_solicitud(request):
    if services.rol_de(request.user) not in [Perfil.PROFESOR, Perfil.ALUMNO]:
        return HttpResponseForbidden("Solo profesores y alumnos pueden solicitar equipos.")
    form = SolicitudForm(request.POST or None, usuario=request.user)
    if request.method == "POST" and form.is_valid():
        try:
            services.crear_solicitud(request.user, form.cleaned_data["equipo"],
                form.cleaned_data["desde"], form.cleaned_data["hasta"], form.cleaned_data["motivo"])
            messages.success(request, "Solicitud creada y guardada. Está pendiente de autorización.")
            return redirect("solicitudes")
        except ValidationError as exc:
            form.add_error(None, exc)
    return render(request, "prestamos/formulario.html", {
        "form": form, "titulo": "Solicitar equipo", "admin_activo": False,
    })


@login_required
@require_POST
def transicionar(request, pk, accion):
    if accion != "cancelar" and not es_admin(request.user):
        return HttpResponseForbidden("Solo el administrador puede realizar esta acción.")
    operaciones = {
        "aprobar": lambda: services.aprobar(request.user, pk),
        "rechazar": lambda: services.rechazar(request.user, pk, request.POST.get("motivo_rechazo", "")),
        "entregar": lambda: services.entregar(request.user, pk, request.POST.get("condicion_salida", "Sin observaciones")),
        "devolver": lambda: services.devolver(request.user, pk, request.POST.get("condicion_retorno", "Sin observaciones"), request.POST.get("incidencia", "")),
        "resolver": lambda: services.resolver_incidencia(request.user, pk),
        "cancelar": lambda: services.cancelar(request.user, pk),
    }
    if accion not in operaciones:
        return HttpResponseForbidden("Acción desconocida.")
    try:
        operaciones[accion]()
        messages.success(request, f"Operación '{accion}' guardada correctamente.")
    except ValidationError as exc:
        messages.error(request, "; ".join(exc.messages))
    return redirect("solicitudes")


@login_required
@never_cache
def historial(request):
    qs = Movimiento.objects.select_related("solicitud__equipo", "solicitud__solicitante", "actor")
    rol = services.rol_de(request.user)
    if rol not in (Perfil.ADMIN, Perfil.PROFESOR, Perfil.ALUMNO):
        return HttpResponseForbidden("Esta cuenta no tiene un perfil habilitado.")
    if rol != Perfil.ADMIN:
        qs = qs.filter(solicitud__solicitante=request.user)
    return render(request, "prestamos/historial.html", {"movimientos": qs[:150], "admin_activo": es_admin(request.user)})


@login_required
@never_cache
def configuracion(request):
    denegado = solo_admin(request)
    if denegado:
        return denegado
    cfg = Configuracion.actual()
    form = ConfiguracionForm(request.POST or None, instance=cfg)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Reglas del colegio actualizadas.")
        return redirect("configuracion")
    return render(request, "prestamos/formulario.html", {"form": form, "titulo": "Configuración del colegio", "admin_activo": True})


@login_required
@never_cache
def calendario(request):
    """Disponibilidad semanal construida con reservas reales de la BD.

    Las solicitudes pendientes NO bloquean una unidad. Los usuarios
    no administradores nunca reciben identidades ajenas en la vista.
    """
    rol = services.rol_de(request.user)
    if rol not in (Perfil.ADMIN, Perfil.PROFESOR, Perfil.ALUMNO):
        return HttpResponseForbidden("No hay un rol habilitado para esta cuenta.")
    admin = rol == Perfil.ADMIN
    # `semana` acepta ISO YYYY-MM-DD; valores inválidos usan hoy.
    valor = request.GET.get("semana", "")
    try:
        fecha = date.fromisoformat(valor) if len(valor) == 10 else timezone.localdate()
    except ValueError:
        fecha = timezone.localdate()
    lunes = fecha - timedelta(days=fecha.weekday())
    domingo = lunes + timedelta(days=6)
    lunes_anterior = lunes - timedelta(days=7)
    lunes_siguiente = lunes + timedelta(days=7)
    dias = [lunes + timedelta(days=n) for n in range(7)]

    # El catálogo visible depende del rol y de la condición real del equipo.
    equipos = Equipo.objects.filter(prestable=True, condicion="operativo").order_by("categoria", "nombre", "codigo")
    if rol == Perfil.ALUMNO:
        equipos = equipos.filter(solo_profesores=False)
    equipos = list(equipos)
    ids_equipos = [equipo.pk for equipo in equipos]
    inicio = timezone.make_aware(datetime.combine(lunes, time.min))
    fin = timezone.make_aware(datetime.combine(domingo + timedelta(days=1), time.min))

    # Solo los estados que reservan/ocupan afectan el calendario.
    reservas = Solicitud.objects.filter(
        equipo_id__in=ids_equipos,
    ).filter(
        Q(estado=Solicitud.APROBADA, desde__lt=fin, hasta__gt=inicio)
        | Q(estado=Solicitud.ENTREGADA, desde__lt=fin)
    ).select_related("solicitante", "equipo").order_by("desde", "pk")
    agrupadas = {}
    for sol in reservas:
        agrupadas.setdefault(sol.equipo_id, []).append(sol)

    filas = []
    for equipo in equipos:
        celdas = []
        for dia in dias:
            ocupaciones = []
            for sol in agrupadas.get(equipo.pk, []):
                inicio_local, fin_local = timezone.localtime(sol.desde), timezone.localtime(sol.hasta)
                if inicio_local.date() <= dia and (dia <= fin_local.date() or sol.estado == Solicitud.ENTREGADA):
                    vencido = sol.estado == Solicitud.ENTREGADA and dia > fin_local.date()
                    ocupaciones.append({
                        "desde": inicio_local, "hasta": fin_local,
                        "estado": "atrasada" if vencido else sol.estado,
                        # No revelar datos de otro usuario a solicitantes.
                        "usuario": sol.solicitante.username if admin else "",
                    })
            celdas.append({"fecha": dia, "ocupaciones": ocupaciones})
        filas.append({"equipo": equipo, "dias": celdas})
    return render(request, "prestamos/calendario.html", {
        "admin_activo": admin, "dias": dias, "filas": filas,
        "lunes": lunes, "domingo": domingo,
        "anterior": lunes_anterior.isoformat(),
        "siguiente": lunes_siguiente.isoformat(),
        "hoy": timezone.localdate(),
    })


@login_required
@never_cache
def reportes(request):
    """Estadísticas de prototipo para el administrador (no contienen datos personales de alumnos)."""
    if not es_admin(request.user):
        return HttpResponseForbidden("Solo administradores.")
    filtro = request.GET.get("estado", "")
    qs = Solicitud.objects.select_related("equipo", "solicitante")
    validos = {codigo for codigo, _ in Solicitud.ESTADOS}
    if filtro in validos:
        qs = qs.filter(estado=filtro)
    else:
        filtro = ""
    from django.db.models import Count
    stats = Solicitud.objects.values("estado").annotate(total=Count("id")).order_by("estado")
    return render(request, "prestamos/reportes.html", {
        "admin_activo": True,
        "estado_filtro": filtro,
        "filtros": Solicitud.ESTADOS,
        "estados": stats,
        "solicitudes": qs.order_by("-creado", "-id")[:100],
        "total": Solicitud.objects.count(),
    })


@login_required
@never_cache
def exportar_reporte(request):
    """CSV de uso administrativo, mitiga inyección de fórmulas en hojas de cálculo."""
    if not es_admin(request.user):
        return HttpResponseForbidden("Solo administradores.")
    import csv
    from django.http import HttpResponse
    response = HttpResponse(content_type="text/csv; charset=utf-8")
    response["Content-Disposition"] = 'attachment; filename="turno_reporte.csv"'
    response["Cache-Control"] = "no-store"
    response.write("\ufeff")
    writer = csv.writer(response)
    writer.writerow(["ID", "Equipo", "Solicitante", "Inicio", "Fin", "Estado", "Incidencia abierta"])
    def seguro(texto):
        v = str(texto)
        # Evitar que Excel/Calc evalúe celdas externas como fórmulas.
        return "'" + v if v and v.lstrip().startswith(("=", "+", "-", "@", "\t", "\r", "\n")) else v
    for sol in Solicitud.objects.select_related("equipo", "solicitante").order_by("pk").iterator():
        writer.writerow([sol.pk, seguro(sol.equipo.nombre), seguro(sol.solicitante.username),
                         timezone.localtime(sol.desde).isoformat(), timezone.localtime(sol.hasta).isoformat(),
                         sol.get_estado_display(), "Sí" if sol.incidencia_abierta else "No"])
    return response


def service_worker(request):
    """Se sirve en raíz para que el SW tenga alcance PWA; jamás cachea HTML privado."""
    from django.http import FileResponse
    from django.conf import settings
    return FileResponse((settings.BASE_DIR / "static" / "turno" / "sw.js").open("rb"),
                        content_type="application/javascript", headers={"Service-Worker-Allowed": "/", "Cache-Control": "no-cache"})


@login_required
@never_cache
def usuarios(request):
    if not es_admin(request.user):
        return HttpResponseForbidden("Solo administradores.")
    usuarios = get_user_model().objects.select_related("perfil").order_by("username")
    return render(request, "prestamos/usuarios.html", {"usuarios": usuarios, "admin_activo": True})


@login_required
@never_cache
@transaction.atomic
def usuario_nuevo(request):
    if not es_admin(request.user):
        return HttpResponseForbidden("Solo administradores.")
    form = UsuarioNuevoForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        usuario = form.save(commit=False)
        rol = form.cleaned_data["rol"]
        usuario.is_staff = rol == Perfil.ADMIN
        usuario.save()
        Perfil.objects.create(usuario=usuario, rol=rol)
        messages.success(request, "Usuario registrado con contraseña protegida.")
        return redirect("usuarios")
    return render(request, "prestamos/formulario.html", {"form": form, "titulo": "Crear usuario", "admin_activo": True})


@login_required
@never_cache
@transaction.atomic
def usuario_editar(request, pk):
    if not es_admin(request.user):
        return HttpResponseForbidden("Solo administradores.")
    usuario = get_object_or_404(get_user_model(), pk=pk)
    if usuario.is_superuser and not request.user.is_superuser:
        return HttpResponseForbidden("Solo un superusuario puede editar a otro superusuario.")
    form = UsuarioEditarForm(request.POST or None, instance=usuario)
    if request.method == "POST" and form.is_valid():
        rol = form.cleaned_data["rol"]
        if usuario.pk == request.user.pk and (not form.cleaned_data["is_active"] or rol != Perfil.ADMIN):
            form.add_error(None, "No puedes desactivar tu propia cuenta ni eliminar tus permisos de administrador.")
        elif usuario.is_superuser and (not form.cleaned_data["is_active"] or rol != Perfil.ADMIN):
            form.add_error(None, "No puedes desactivar ni cambiar el rol de un superusuario desde este formulario.")
        else:
            objeto = form.save(commit=False)
            objeto.is_staff = rol == Perfil.ADMIN
            objeto.save()
            Perfil.objects.update_or_create(usuario=objeto, defaults={"rol": rol})
            messages.success(request, "Usuario actualizado. Se conserva el historial de préstamos.")
            return redirect("usuarios")
    return render(request, "prestamos/formulario.html", {"form": form, "titulo": "Editar usuario", "admin_activo": True})


@login_required
@never_cache
@transaction.atomic
def usuario_clave(request, pk):
    if not es_admin(request.user):
        return HttpResponseForbidden("Solo administradores.")
    usuario = get_object_or_404(get_user_model(), pk=pk)
    if usuario.is_superuser and not request.user.is_superuser:
        return HttpResponseForbidden("Solo un superusuario puede cambiar esta contraseña.")
    form = UsuarioClaveForm(user=usuario, data=request.POST or None)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Contraseña actualizada. Comunícala al titular por un canal seguro.")
        return redirect("usuarios")
    return render(request, "prestamos/formulario.html", {"form": form, "titulo": f"Cambiar contraseña de {usuario.username}", "admin_activo": True})
