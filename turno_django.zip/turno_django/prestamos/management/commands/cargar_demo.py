import secrets
from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from prestamos.models import Equipo, Perfil, Configuracion


class Command(BaseCommand):
    help = "Crea tres usuarios ficticios con claves aleatorias y equipos para pruebas locales."

    def handle(self, *args, **kwargs):
        User = get_user_model()
        Configuracion.actual()
        people = [
            ("admin_demo", "Paula", "Núñez", Perfil.ADMIN),
            ("prof_demo", "Valeria", "Rojas", Perfil.PROFESOR),
            ("alum_demo", "Matías", "Díaz", Perfil.ALUMNO),
        ]
        for username, first, last, role in people:
            if User.objects.filter(username=username).exists():
                self.stdout.write(f"Ya existe {username}: contraseña conservada.")
                continue
            password = secrets.token_urlsafe(14)
            usr = User.objects.create_user(username=username, password=password,
                first_name=first, last_name=last, is_staff=(role == Perfil.ADMIN))
            Perfil.objects.create(usuario=usr, rol=role)
            self.stdout.write(f"{username} -> {password} (guarda esta clave; se muestra una sola vez)")
        data = [
            ("PRO-014", "Proyector Epson", "Audiovisual", False),
            ("NB-07", "Notebook Lenovo 14", "Tecnología", False),
            ("CAL-03", "Calculadora científica", "Matemática", False),
            ("ROB-02", "Kit de robótica Arduino", "Ciencias", True),
            ("MIC-05", "Microscopio binocular", "Ciencias", False),
        ]
        for codigo, nombre, categoria, exclusivo in data:
            Equipo.objects.get_or_create(codigo=codigo, defaults={
                "nombre": nombre, "categoria": categoria, "solo_profesores": exclusivo,
            })
        self.stdout.write(self.style.SUCCESS("Datos ficticios preparados. No uses estas cuentas en producción."))
