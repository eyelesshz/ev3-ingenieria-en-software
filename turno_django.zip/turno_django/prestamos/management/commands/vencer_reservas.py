from django.core.management.base import BaseCommand
from prestamos.services import vencer_reservas_vencidas

class Command(BaseCommand):
    help = "Libera reservas aprobadas cuyo período ya terminó y no se retiraron."
    def handle(self, *args, **options):
        total = vencer_reservas_vencidas()
        self.stdout.write(self.style.SUCCESS(f"Reservas vencidas: {total}"))
