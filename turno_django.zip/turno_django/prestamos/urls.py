from django.urls import path
from . import views

urlpatterns = [
    path("", views.inicio, name="inicio"),
    path("inventario/", views.inventario, name="inventario"),
    path("calendario/", views.calendario, name="calendario"),
    path("inventario/nuevo/", views.editar_equipo, name="equipo_nuevo"),
    path("inventario/<str:codigo>/editar/", views.editar_equipo, name="equipo_editar"),
    path("inventario/<str:codigo>/baja/", views.dar_de_baja, name="equipo_baja"),
    path("solicitudes/", views.solicitudes, name="solicitudes"),
    path("solicitudes/nueva/", views.nueva_solicitud, name="solicitud_nueva"),
    path("solicitudes/<int:pk>/<str:accion>/", views.transicionar, name="solicitud_accion"),
    path("historial/", views.historial, name="historial"),
    path("reportes/", views.reportes, name="reportes"),
    path("usuarios/", views.usuarios, name="usuarios"),
    path("usuarios/nuevo/", views.usuario_nuevo, name="usuario_nuevo"),
    path("usuarios/<int:pk>/editar/", views.usuario_editar, name="usuario_editar"),
    path("usuarios/<int:pk>/clave/", views.usuario_clave, name="usuario_clave"),
    path("reportes/csv/", views.exportar_reporte, name="exportar_reporte"),
    path("sw.js", views.service_worker, name="service_worker"),
    path("configuracion/", views.configuracion, name="configuracion"),
]
