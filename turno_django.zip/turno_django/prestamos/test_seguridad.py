"""Pruebas OWASP: acceso, CSRF, sesiones, XSS, autenticación y configuración.
Ejecutar: python manage.py test prestamos
"""
from datetime import datetime, time, timedelta
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.core.exceptions import ValidationError
from django.test import Client, TestCase, override_settings
from django.utils import timezone

from . import services
from .models import Configuracion, Equipo, Movimiento, Perfil, Solicitud


class SeguridadTurnoTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        U = get_user_model()
        cls.admin = U.objects.create_user(username="seg_admin", password="Password_Abc123!", is_staff=True)
        cls.prof = U.objects.create_user(username="seg_prof", password="Password_Abc123!")
        cls.alumno = U.objects.create_user(username="seg_alumno", password="Password_Abc123!")
        cls.alumno2 = U.objects.create_user(username="seg_alumno2", password="Password_Abc123!")
        cls.sin_rol = U.objects.create_user(username="seg_sin_rol", password="Password_Abc123!")
        Perfil.objects.create(usuario=cls.admin, rol=Perfil.ADMIN)
        Perfil.objects.create(usuario=cls.prof, rol=Perfil.PROFESOR)
        Perfil.objects.create(usuario=cls.alumno, rol=Perfil.ALUMNO)
        Perfil.objects.create(usuario=cls.alumno2, rol=Perfil.ALUMNO)
        cls.equipo = Equipo.objects.create(codigo="SEG-1", nombre="Proyector Seg", categoria="Tecnología")
        cls.restringido = Equipo.objects.create(codigo="SEG-2", nombre="Kit exclusivo secreto", categoria="Tecnología", solo_profesores=True)
        cfg = Configuracion.actual()
        cfg.solicitud_desde, cfg.solicitud_hasta = time(0, 0), time(23, 59, 59)
        cfg.atencion_desde, cfg.atencion_hasta = time(0, 0), time(23, 59, 59)
        cfg.duracion_maxima_horas = 6
        cfg.save()

    def setUp(self):
        cache.clear()

    def ventana(self):
        dia = timezone.localdate() + timedelta(days=3)
        desde = timezone.make_aware(datetime.combine(dia, time(10, 0)))
        return desde, desde + timedelta(hours=1)

    def test_contraseñas_almacenadas_como_hash(self):
        self.assertNotEqual(self.alumno.password, "Password_Abc123!")
        self.assertTrue(self.alumno.check_password("Password_Abc123!"))

    def test_pagina_privada_redirecciona_a_login(self):
        response = self.client.get("/historial/")
        self.assertEqual(response.status_code, 302)
        self.assertIn("entrar", response.url)

    def test_alumno_no_ve_equipo_docente_en_inventario(self):
        self.client.force_login(self.alumno)
        response = self.client.get("/inventario/")
        self.assertEqual(response.status_code, 200)
        self.assertNotContains(response, "Kit exclusivo secreto")

    def test_usuario_sin_rol_no_ve_inventario(self):
        self.client.force_login(self.sin_rol)
        self.assertEqual(self.client.get("/inventario/").status_code, 403)

    def test_staff_sin_rol_no_es_administrador_turno(self):
        self.sin_rol.is_staff = True
        self.sin_rol.save(update_fields=["is_staff"])
        self.assertIsNone(services.rol_de(self.sin_rol))

    def test_alumno_no_ve_historial_ajeno(self):
        desde, hasta = self.ventana()
        services.crear_solicitud(self.prof, self.equipo, desde, hasta, "motivo privado profesorado")
        self.client.force_login(self.alumno)
        response = self.client.get("/historial/")
        self.assertNotContains(response, "motivo privado profesorado")
        self.assertNotContains(response, "seg_prof")

    def test_alumno_no_puede_aprobar_por_url_directa(self):
        desde, hasta = self.ventana()
        sol = services.crear_solicitud(self.prof, self.equipo, desde, hasta, "Clase")
        self.client.force_login(self.alumno)
        response = self.client.post(f"/solicitudes/{sol.pk}/aprobar/")
        self.assertEqual(response.status_code, 403)
        sol.refresh_from_db()
        self.assertEqual(sol.estado, Solicitud.PENDIENTE)

    def test_alumno_no_puede_cancelar_solicitud_ajena(self):
        desde, hasta = self.ventana()
        sol = services.crear_solicitud(self.prof, self.equipo, desde, hasta, "Clase")
        self.client.force_login(self.alumno)
        self.client.post(f"/solicitudes/{sol.pk}/cancelar/")
        sol.refresh_from_db()
        self.assertEqual(sol.estado, Solicitud.PENDIENTE)

    def test_alumno_no_ve_reportes_ni_csv(self):
        self.client.force_login(self.alumno)
        self.assertEqual(self.client.get("/reportes/").status_code, 403)
        self.assertEqual(self.client.get("/reportes/csv/").status_code, 403)

    def test_csrf_impide_post_sin_token(self):
        client = Client(enforce_csrf_checks=True)
        client.force_login(self.alumno)
        response = client.post("/solicitudes/nueva/", data={})
        self.assertEqual(response.status_code, 403)

    def test_escapado_xss_en_pantallas(self):
        desde, hasta = self.ventana()
        services.crear_solicitud(self.alumno, self.equipo, desde, hasta, '<script>alert("xss")</script>')
        self.client.force_login(self.alumno)
        response = self.client.get("/solicitudes/")
        self.assertContains(response, "&lt;script&gt;")
        self.assertNotContains(response, '<script>alert("xss")</script>')

    def test_cabeceras_seguridad(self):
        response = self.client.get("/cuentas/entrar/")
        self.assertEqual(response.status_code, 200)
        self.assertIn("frame-ancestors 'none'", response["Content-Security-Policy"])
        self.assertEqual(response["X-Frame-Options"], "DENY")
        self.assertEqual(response["X-Content-Type-Options"], "nosniff")

    @override_settings(LOGIN_MAX_INTENTOS=3, LOGIN_BLOQUEO_SEGUNDOS=300)
    def test_limite_intentos_login(self):
        for _ in range(3):
            response = self.client.post("/cuentas/entrar/", data={"username": "seg_alumno", "password": "incorrecta"})
            self.assertEqual(response.status_code, 200)
        response = self.client.post("/cuentas/entrar/", data={"username": "seg_alumno", "password": "incorrecta"})
        self.assertEqual(response.status_code, 429)
        self.assertEqual(response["Retry-After"], "300")

    def test_pwa_servida_sin_cachear_paginas_privadas(self):
        response = self.client.get("/sw.js")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response["Service-Worker-Allowed"], "/")
        contenido = b"".join(response.streaming_content)
        response.close()
        self.assertIn(b"PUBLIC_ASSETS", contenido)
        self.assertIn(b'event.request.method !== "GET"', contenido)

    def test_csv_escapa_formula(self):
        Equipo.objects.create(codigo="SEG-X", nombre="=SUM(1+1)", categoria="Test")
        desde, hasta = self.ventana()
        services.crear_solicitud(self.prof, Equipo.objects.get(pk="SEG-X"), desde, hasta, "Clase")
        self.client.force_login(self.admin)
        response = self.client.get("/reportes/csv/")
        self.assertEqual(response.status_code, 200)
        self.assertIn("'=SUM(1+1)", response.content.decode("utf-8-sig"))

    def test_equipo_prestado_bloquea_aprobacion_futura(self):
        desde, hasta = self.ventana()
        sol1 = services.crear_solicitud(self.prof, self.equipo, desde, hasta, "Clase")
        services.aprobar(self.admin, sol1.pk)
        services.entregar(self.admin, sol1.pk)
        desde2 = desde + timedelta(days=1)
        sol2 = services.crear_solicitud(self.alumno, self.equipo, desde2, desde2 + timedelta(hours=1), "Clase 2")
        with self.assertRaises(ValidationError):
            services.aprobar(self.admin, sol2.pk)

    def test_incidencia_bloquea_hasta_resolucion(self):
        desde, hasta = self.ventana()
        sol = services.crear_solicitud(self.prof, self.equipo, desde, hasta, "Clase")
        services.aprobar(self.admin, sol.pk)
        services.entregar(self.admin, sol.pk)
        services.devolver(self.admin, sol.pk, incidente="Falta cargador")
        self.assertTrue(services.titular_bloqueado(self.prof))
        services.resolver_incidencia(self.admin, sol.pk)
        self.assertFalse(services.titular_bloqueado(self.prof))

    def test_vencimiento_libera_reserva_y_guarda_movimiento(self):
        desde, hasta = self.ventana()
        sol = services.crear_solicitud(self.prof, self.equipo, desde, hasta, "Clase")
        services.aprobar(self.admin, sol.pk)
        ahora = timezone.now()
        Solicitud.objects.filter(pk=sol.pk).update(desde=ahora-timedelta(hours=2), hasta=ahora-timedelta(hours=1))
        cantidad = services.vencer_reservas_vencidas()
        self.assertEqual(cantidad, 1)
        sol.refresh_from_db()
        self.assertEqual(sol.estado, Solicitud.VENCIDA)
        self.assertTrue(Movimiento.objects.filter(solicitud=sol, accion="vencer").exists())

    def test_editar_equipo_activo_impide_cambiar_condicion(self):
        desde, hasta = self.ventana()
        sol = services.crear_solicitud(self.prof, self.equipo, desde, hasta, "Clase")
        services.aprobar(self.admin, sol.pk)
        self.client.force_login(self.admin)
        response = self.client.post(f"/inventario/{self.equipo.pk}/editar/", data={
            "codigo": self.equipo.pk, "nombre": self.equipo.nombre, "categoria": self.equipo.categoria,
            "condicion": "reparacion", "prestable": "on", "solo_profesores": "",
        })
        self.assertEqual(response.status_code, 200)
        self.equipo.refresh_from_db()
        self.assertEqual(self.equipo.condicion, "operativo")

    def test_admin_crea_usuario_y_perfil(self):
        self.client.force_login(self.admin)
        response = self.client.post("/usuarios/nuevo/", data={
            "username": "nuevo_alumno", "first_name": "N", "last_name": "Alumno", "email": "",
            "rol": Perfil.ALUMNO, "password1": "StrongPassword!2026", "password2": "StrongPassword!2026",
        })
        self.assertEqual(response.status_code, 302)
        nuevo = get_user_model().objects.get(username="nuevo_alumno")
        self.assertTrue(nuevo.check_password("StrongPassword!2026"))
        self.assertEqual(nuevo.perfil.rol, Perfil.ALUMNO)
        self.assertFalse(nuevo.is_staff)

    def test_alumno_no_puede_crear_usuarios(self):
        self.client.force_login(self.alumno)
        self.assertEqual(self.client.get("/usuarios/nuevo/").status_code, 403)
        self.assertEqual(self.client.get("/usuarios/").status_code, 403)

    def test_admin_no_puede_desactivarse_a_si_mismo(self):
        self.client.force_login(self.admin)
        response = self.client.post(f"/usuarios/{self.admin.pk}/editar/", data={
            "first_name": "", "last_name": "", "email": "", "rol": Perfil.ADMIN,
            # Si omitimos 'is_active', ModelForm lo toma como False.
        })
        self.assertEqual(response.status_code, 200)
        self.admin.refresh_from_db()
        self.assertTrue(self.admin.is_active)

    def test_calendario_muestra_atraso_hasta_devolucion(self):
        desde, hasta = self.ventana()
        sol = services.crear_solicitud(self.prof, self.equipo, desde, hasta, "Clase")
        services.aprobar(self.admin, sol.pk)
        services.entregar(self.admin, sol.pk)
        fecha_futura = (desde + timedelta(days=4)).date()
        self.client.force_login(self.admin)
        respuesta = self.client.get("/calendario/", {"semana": fecha_futura.isoformat()})
        self.assertContains(respuesta, "Atrasado, sin devolver")
        services.devolver(self.admin, sol.pk)
        respuesta = self.client.get("/calendario/", {"semana": fecha_futura.isoformat()})
        self.assertNotContains(respuesta, "Atrasado, sin devolver")
