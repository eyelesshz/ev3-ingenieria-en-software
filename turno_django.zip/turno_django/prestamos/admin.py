from django.contrib import admin
from .models import Perfil, Equipo, Configuracion, Solicitud, Movimiento

@admin.register(Perfil)
class PerfilAdmin(admin.ModelAdmin):
    list_display = ("usuario", "rol")
    list_filter = ("rol",)

@admin.register(Equipo)
class EquipoAdmin(admin.ModelAdmin):
    list_display = ("codigo", "nombre", "categoria", "condicion", "prestable", "solo_profesores")
    list_filter = ("condicion", "categoria", "solo_profesores")
    search_fields = ("codigo", "nombre")

@admin.register(Configuracion)
class ConfiguracionAdmin(admin.ModelAdmin):
    def has_add_permission(self, request):
        return not Configuracion.objects.exists() and super().has_add_permission(request)

@admin.register(Solicitud)
class SolicitudAdmin(admin.ModelAdmin):
    list_display = ("id", "equipo", "solicitante", "desde", "hasta", "estado", "incidencia_abierta")
    list_filter = ("estado", "incidencia_abierta")
    readonly_fields = [field.name for field in Solicitud._meta.fields]
    def has_add_permission(self, request):
        return False
    def has_delete_permission(self, request, obj=None):
        return False

@admin.register(Movimiento)
class MovimientoAdmin(admin.ModelAdmin):
    list_display = ("solicitud", "accion", "actor", "fecha")
    readonly_fields = [field.name for field in Movimiento._meta.fields]
    def has_add_permission(self, request):
        return False
    def has_delete_permission(self, request, obj=None):
        return False
