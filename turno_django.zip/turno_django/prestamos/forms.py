from datetime import datetime
from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm, SetPasswordForm
from .models import Perfil
from django.utils import timezone
from .models import Configuracion, Equipo


class EquipoForm(forms.ModelForm):
    class Meta:
        model = Equipo
        fields = ["codigo", "nombre", "categoria", "condicion", "prestable", "solo_profesores"]


class SolicitudForm(forms.Form):
    equipo = forms.ModelChoiceField(queryset=Equipo.objects.none(), empty_label="Selecciona un equipo")
    fecha = forms.DateField(widget=forms.DateInput(attrs={"type": "date"}))
    hora_inicio = forms.TimeField(widget=forms.TimeInput(format="%H:%M", attrs={"type": "time"}), input_formats=["%H:%M"])
    hora_fin = forms.TimeField(widget=forms.TimeInput(format="%H:%M", attrs={"type": "time"}), input_formats=["%H:%M"])
    motivo = forms.CharField(max_length=240, widget=forms.Textarea(attrs={"rows": 3}))

    def __init__(self, *args, usuario=None, **kwargs):
        super().__init__(*args, **kwargs)
        qs = Equipo.objects.filter(prestable=True, condicion="operativo")
        if usuario is not None and getattr(usuario.perfil, "rol", "alum") == "alum":
            qs = qs.filter(solo_profesores=False)
        self.fields["equipo"].queryset = qs.order_by("nombre")

    def clean(self):
        cleaned = super().clean()
        if all(cleaned.get(k) for k in ["fecha", "hora_inicio", "hora_fin"]):
            fecha = cleaned["fecha"]
            tz = timezone.get_current_timezone()
            inicio = timezone.make_aware(datetime.combine(fecha, cleaned["hora_inicio"]), tz)
            termino = timezone.make_aware(datetime.combine(fecha, cleaned["hora_fin"]), tz)
            cleaned["desde"] = inicio
            cleaned["hasta"] = termino
        return cleaned


class ConfiguracionForm(forms.ModelForm):
    class Meta:
        model = Configuracion
        fields = [
            "prestamos_habilitados", "alumnos_habilitados", "prioridad_docente",
            "bloqueo_pendientes", "solicitud_desde", "solicitud_hasta",
            "atencion_desde", "atencion_hasta", "duracion_maxima_horas",
        ]
        widgets = {k: forms.TimeInput(format="%H:%M", attrs={"type": "time"}) for k in [
            "solicitud_desde", "solicitud_hasta", "atencion_desde", "atencion_hasta",
        ]}

    def clean(self):
        data = super().clean()
        if data.get("atencion_desde") and data.get("atencion_hasta") and data["atencion_desde"] >= data["atencion_hasta"]:
            self.add_error("atencion_hasta", "Debe ser posterior al inicio.")
        if data.get("solicitud_desde") and data.get("solicitud_hasta") and data["solicitud_desde"] >= data["solicitud_hasta"]:
            self.add_error("solicitud_hasta", "Debe ser posterior al inicio.")
        if data.get("duracion_maxima_horas") and data["duracion_maxima_horas"] > 24:
            self.add_error("duracion_maxima_horas", "No puede superar 24 horas.")
        return data


class UsuarioNuevoForm(UserCreationForm):
    rol = forms.ChoiceField(choices=Perfil.ROLES, label="Perfil de Turno")

    class Meta(UserCreationForm.Meta):
        model = get_user_model()
        fields = ("username", "first_name", "last_name", "email")


class UsuarioEditarForm(forms.ModelForm):
    rol = forms.ChoiceField(choices=Perfil.ROLES, label="Perfil de Turno")

    class Meta:
        model = get_user_model()
        fields = ("first_name", "last_name", "email", "is_active")
        labels = {"is_active": "Cuenta activa"}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance.pk:
            self.fields["rol"].initial = getattr(getattr(self.instance, "perfil", None), "rol", Perfil.ALUMNO)


class UsuarioClaveForm(SetPasswordForm):
    """Usa validación y hasheado nativos de Django, nunca guarda texto plano."""
