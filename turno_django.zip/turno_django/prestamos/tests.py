from datetime import timedelta, datetime, time
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.test import TestCase
from django.utils import timezone
from .models import Configuracion, Equipo, Movimiento, Perfil, Solicitud
from . import services


class FlujoPrestamosTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        U = get_user_model()
        cls.admin = U.objects.create_user(username="admin", password="Pass_123456!", is_staff=True)
        cls.profesor = U.objects.create_user(username="profesor", password="Pass_123456!")
        cls.alumno = U.objects.create_user(username="alumno", password="Pass_123456!")
        Perfil.objects.create(usuario=cls.admin, rol=Perfil.ADMIN)
        Perfil.objects.create(usuario=cls.profesor, rol=Perfil.PROFESOR)
        Perfil.objects.create(usuario=cls.alumno, rol=Perfil.ALUMNO)
        cls.equipo = Equipo.objects.create(codigo="PR-01", nombre="Proyector", categoria="Tecnología")
        cfg = Configuracion.actual()
        cfg.solicitud_desde, cfg.solicitud_hasta = time(0, 0), time(23, 59, 59)
        cfg.atencion_desde, cfg.atencion_hasta = time(0, 0), time(23, 59, 59)
        cfg.duracion_maxima_horas = 6
        cfg.save()

    def ventana(self):
        fecha = timezone.localdate() + timedelta(days=2)
        inicio = timezone.make_aware(datetime.combine(fecha, time(10, 0)))
        return inicio, inicio + timedelta(hours=1)

    def test_ciclo_completo(self):
        desde, hasta = self.ventana()
        sol = services.crear_solicitud(self.profesor, self.equipo, desde, hasta, "Clase de historia")
        self.assertEqual(sol.estado, Solicitud.PENDIENTE)
        services.aprobar(self.admin, sol.pk)
        services.entregar(self.admin, sol.pk, "Completo")
        services.devolver(self.admin, sol.pk, "Buen estado")
        sol.refresh_from_db()
        self.assertEqual(sol.estado, Solicitud.CERRADA)
        self.assertEqual(Movimiento.objects.filter(solicitud=sol).count(), 4)

    def test_alumno_no_pide_equipo_exclusivo(self):
        self.equipo.solo_profesores = True
        self.equipo.save()
        desde, hasta = self.ventana()
        with self.assertRaises(ValidationError):
            services.crear_solicitud(self.alumno, self.equipo, desde, hasta, "Práctica")

    def test_docente_tiene_prioridad_en_conflicto(self):
        desde, hasta = self.ventana()
        sol_alumno = services.crear_solicitud(self.alumno, self.equipo, desde, hasta, "Exposición")
        sol_profe = services.crear_solicitud(self.profesor, self.equipo, desde, hasta, "Clase")
        with self.assertRaises(ValidationError):
            services.aprobar(self.admin, sol_alumno.pk)
        services.aprobar(self.admin, sol_profe.pk)
        with self.assertRaises(ValidationError):
            services.aprobar(self.admin, sol_alumno.pk)

    def test_alumno_no_puede_aprobar(self):
        desde, hasta = self.ventana()
        sol = services.crear_solicitud(self.profesor, self.equipo, desde, hasta, "Clase")
        with self.assertRaises(ValidationError):
            services.aprobar(self.alumno, sol.pk)

    def test_incidencia_bloquea_nueva_solicitud(self):
        desde, hasta = self.ventana()
        sol = services.crear_solicitud(self.profesor, self.equipo, desde, hasta, "Clase")
        services.aprobar(self.admin, sol.pk)
        services.entregar(self.admin, sol.pk)
        services.devolver(self.admin, sol.pk, incidente="Falta el cable")
        nuevo_inicio = desde + timedelta(days=1)
        with self.assertRaises(ValidationError):
            services.crear_solicitud(self.profesor, self.equipo, nuevo_inicio, nuevo_inicio + timedelta(hours=1), "Clase nueva")
        services.resolver_incidencia(self.admin, sol.pk)
        nuevo = services.crear_solicitud(self.profesor, self.equipo, nuevo_inicio, nuevo_inicio + timedelta(hours=1), "Clase nueva")
        self.assertEqual(nuevo.estado, Solicitud.PENDIENTE)

    def test_no_se_permite_duplicar_aprobacion(self):
        desde, hasta = self.ventana()
        sol1 = services.crear_solicitud(self.profesor, self.equipo, desde, hasta, "Clase 1")
        # No se considera la misma fecha y hora creación estricta para orden aquí.
        sol2 = services.crear_solicitud(self.profesor, self.equipo, desde, hasta, "Clase 2")
        services.aprobar(self.admin, sol1.pk)
        with self.assertRaises(ValidationError):
            services.aprobar(self.admin, sol2.pk)

    def test_historial_ajeno_no_visible(self):
        desde, hasta = self.ventana()
        services.crear_solicitud(self.profesor, self.equipo, desde, hasta, "Clase")
        self.client.force_login(self.alumno)
        respuesta = self.client.get("/historial/")
        self.assertEqual(respuesta.status_code, 200)
        self.assertNotContains(respuesta, "Clase")

    def test_solo_admin_edita_inventario(self):
        self.client.force_login(self.alumno)
        respuesta = self.client.post("/inventario/nuevo/", {
            "codigo": "MAL-01", "nombre": "Intento", "categoria": "No autorizado", "condicion": "operativo", "prestable": "on"
        })
        self.assertEqual(respuesta.status_code, 403)
        self.assertFalse(Equipo.objects.filter(codigo="MAL-01").exists())


class CalendarioTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        U = get_user_model()
        cls.admin = U.objects.create_user(username="admin_cal", password="Pass_123456!", is_staff=True)
        cls.profesor = U.objects.create_user(username="profesor_cal", password="Pass_123456!")
        cls.alumno = U.objects.create_user(username="alumno_cal", password="Pass_123456!")
        Perfil.objects.create(usuario=cls.admin, rol=Perfil.ADMIN)
        Perfil.objects.create(usuario=cls.profesor, rol=Perfil.PROFESOR)
        Perfil.objects.create(usuario=cls.alumno, rol=Perfil.ALUMNO)
        cls.equipo = Equipo.objects.create(codigo="CAL-01", nombre="Proyector calendario", categoria="Tecnología")
        cfg = Configuracion.actual()
        cfg.solicitud_desde, cfg.solicitud_hasta = time(0, 0), time(23, 59, 59)
        cfg.atencion_desde, cfg.atencion_hasta = time(0, 0), time(23, 59, 59)
        cfg.duracion_maxima_horas = 6
        cfg.save()

    def ventana(self):
        fecha = timezone.localdate() + timedelta(days=2)
        inicio = timezone.make_aware(datetime.combine(fecha, time(10, 0)))
        return inicio, inicio + timedelta(hours=1)

    def test_calendario_exige_sesion(self):
        respuesta = self.client.get("/calendario/")
        self.assertEqual(respuesta.status_code, 302)
        self.assertIn("entrar", respuesta.url)

    def test_calendario_muestra_reserva_aprobada(self):
        desde, hasta = self.ventana()
        sol = services.crear_solicitud(self.profesor, self.equipo, desde, hasta, "Clase")
        services.aprobar(self.admin, sol.pk)
        self.client.force_login(self.admin)
        respuesta = self.client.get("/calendario/", {"semana": desde.date().isoformat()})
        self.assertEqual(respuesta.status_code, 200)
        self.assertContains(respuesta, "Reservado")
        self.assertContains(respuesta, self.equipo.nombre)
        self.assertContains(respuesta, self.profesor.username)

    def test_calendario_pendiente_no_ocupa(self):
        desde, hasta = self.ventana()
        services.crear_solicitud(self.profesor, self.equipo, desde, hasta, "Clase")
        self.client.force_login(self.admin)
        respuesta = self.client.get("/calendario/", {"semana": desde.date().isoformat()})
        self.assertContains(respuesta, "Sin reservas")
        self.assertNotContains(respuesta, "Reservado</strong>")

    def test_alumno_no_ve_identidad_de_profesor(self):
        desde, hasta = self.ventana()
        sol = services.crear_solicitud(self.profesor, self.equipo, desde, hasta, "Clase")
        services.aprobar(self.admin, sol.pk)
        self.client.force_login(self.alumno)
        respuesta = self.client.get("/calendario/", {"semana": desde.date().isoformat()})
        self.assertContains(respuesta, "Reservado")
        self.assertNotContains(respuesta, self.profesor.username)

    def test_alumno_no_ve_equipo_exclusivo(self):
        self.equipo.solo_profesores = True
        self.equipo.save(update_fields=["solo_profesores"])
        self.client.force_login(self.alumno)
        respuesta = self.client.get("/calendario/")
        self.assertNotContains(respuesta, self.equipo.nombre)
