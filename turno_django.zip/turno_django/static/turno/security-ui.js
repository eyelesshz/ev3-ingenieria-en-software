"use strict";
// Confirmaciones con JS externo, compatible con CSP sin unsafe-inline.
document.addEventListener("submit", function (event) {
  const formulario = event.target;
  if (formulario instanceof HTMLFormElement && formulario.dataset.confirm) {
    if (!window.confirm(formulario.dataset.confirm)) event.preventDefault();
  }
});
