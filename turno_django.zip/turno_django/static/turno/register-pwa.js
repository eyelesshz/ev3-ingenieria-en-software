"use strict";
// PWA solo instala recursos estáticos. Nunca almacena en caché sesiones ni páginas privadas.
if ("serviceWorker" in navigator && window.isSecureContext) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js", { scope: "/" }).catch(() => {
      // No afecta las operaciones del préstamo; requieren conexión al servidor.
    });
  });
}
