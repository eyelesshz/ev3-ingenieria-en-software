"""Mitigación básica de fuerza bruta; NO sustituye WAF ni monitoreo en producción."""
import hashlib
import logging
from django.conf import settings
from django.contrib.auth.views import LoginView
from django.core.cache import cache
from django.http import HttpResponse
from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache

logger = logging.getLogger("turno.seguridad")


@method_decorator(never_cache, name="dispatch")
class InicioSesionProtegido(LoginView):
    template_name = "registration/login.html"

    def _clave(self):
        # REMOTE_ADDR evita confiar en X-Forwarded-For aportado por el cliente.
        ip = self.request.META.get("REMOTE_ADDR", "unknown")[:80]
        token = hashlib.sha256(ip.encode("utf-8")).hexdigest()
        return "turno:login:" + token

    def dispatch(self, request, *args, **kwargs):
        if request.method == "POST" and cache.get(self._clave(), 0) >= settings.LOGIN_MAX_INTENTOS:
            logger.warning("Inicio de sesión temporalmente limitado desde dirección remota")
            response = HttpResponse("Demasiados intentos. Intenta nuevamente más tarde.", status=429, content_type="text/plain; charset=utf-8")
            response["Retry-After"] = str(settings.LOGIN_BLOQUEO_SEGUNDOS)
            return response
        return super().dispatch(request, *args, **kwargs)

    def form_invalid(self, form):
        key = self._clave()
        actual = cache.get(key, 0)
        cache.set(key, actual + 1, timeout=settings.LOGIN_BLOQUEO_SEGUNDOS)
        logger.warning("Intento de inicio de sesión fallido")
        return super().form_invalid(form)

    def form_valid(self, form):
        cache.delete(self._clave())
        return super().form_valid(form)
