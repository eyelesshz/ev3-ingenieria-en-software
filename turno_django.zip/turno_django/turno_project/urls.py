from django.contrib import admin
from django.contrib.auth import views as auth_views
from .auth_views import InicioSesionProtegido
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),
    path("cuentas/entrar/", InicioSesionProtegido.as_view(), name="login"),
    path("cuentas/salir/", auth_views.LogoutView.as_view(), name="logout"),
    path("", include("prestamos.urls")),
]
