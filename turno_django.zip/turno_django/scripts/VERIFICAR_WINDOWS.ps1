# Ejecutar desde turno_django en PowerShell. No altera registros reales.
$ErrorActionPreference = 'Stop'
$python = '.\.venv\Scripts\python.exe'
if (!(Test-Path $python)) { throw 'No se encontró .venv. Abre la carpeta turno_django correcta.' }
& $python manage.py check
if ($LASTEXITCODE -ne 0) { throw 'Falló manage.py check' }
& $python manage.py test prestamos
if ($LASTEXITCODE -ne 0) { throw 'Fallaron las pruebas. Revisa antes de publicar.' }
Write-Host 'Revisiones ejecutadas. Guarda las capturas de la terminal como evidencia.' -ForegroundColor Green
