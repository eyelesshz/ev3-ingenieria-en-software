# Ejecutar desde turno_django. El archivo exportado contiene datos sensibles.
$ErrorActionPreference = 'Stop'
$python = '.\.venv\Scripts\python.exe'
if (!(Test-Path $python)) { throw 'Abre la carpeta turno_django correcta.' }
New-Item -Type Directory -Force '.\backups' | Out-Null
$nombre = 'turno-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.json'
$ruta = Join-Path '.\backups' $nombre
& $python manage.py dumpdata --exclude contenttypes --exclude auth.permission --exclude sessions --exclude admin --indent 2 --output $ruta
if ($LASTEXITCODE -ne 0) { throw 'No se pudo exportar la base de datos.' }
Write-Host "Respaldo guardado: $ruta" -ForegroundColor Green
Write-Host 'Contiene hashes de contraseñas y datos de usuarios. NO compartir ni subir a GitHub.' -ForegroundColor Yellow
