# Para Programador de tareas de Windows. Ejecutar periódico desde turno_django.
$ErrorActionPreference = 'Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
& '.\.venv\Scripts\python.exe' manage.py vencer_reservas
exit $LASTEXITCODE
