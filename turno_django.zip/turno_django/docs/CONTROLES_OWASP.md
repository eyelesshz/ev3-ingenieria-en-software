# Turno — Controles concretos y límites frente a OWASP Top 10:2025

Fuente de clasificación: https://top10.owasp.org/2025/ . Este documento es una guía técnica, **no es un pentest ni garantiza cumplimiento total de OWASP**.

| Categoría | Control o tratamiento en el código | Límite |
|---|---|---|
| A01 — Control de acceso roto | `services.rol_de()`, autorizaciones en vistas y servicios, consultas filtradas por titular, CSV/reportes solo admin | Requiere pruebas de roles y revisión cada vez que se agreguen vistas |
| A02 — Configuración insegura | `SECRET_KEY` por `.env`, `DEBUG=0` para producción, TLS/HSTS/cookies seguros, CSP, XFO, nosniff | Configuración de TLS y proxy debe realizarse en un servidor real |
| A03 — Fallos de cadena de suministro | `requirements.txt`, entorno reproducible, instalar de fuentes confiables | Auditoría de dependencias no automatizada; actualizar y ejecutar `pip-audit` como tarea posterior de infraestructura |
| A04 — Fallos criptográficos | Hashes de Django y sesiones/cookies; variables de ambiente, HTTPS previsto | HTTPS real, certificados, copias cifradas y rotación de claves requieren infraestructura |
| A05 — Inyección | ORM Django parametrizado, formularios, escape automático de HTML, CSP, CSV con protección contra fórmulas | No sustituye revisión de futuras consultas SQL ni de JS que se agregue |
| A06 — Diseño inseguro | Estados y roles, prioridad docente, transacciones y bloqueo de equipos prestados | Probar concurrencia contra PostgreSQL real y errores de red |
| A07 — Fallos de autenticación | Formulario Django con contraseñas hasheadas, sesión HTTPOnly, rate limit básico por IP | Caché local por proceso: para producción distribuida requiere cache compartida/WAF |
| A08 — Integridad de software/datos | Transiciones centralizadas en `services.py`, registro de cambios, baja lógica | No hay firmas digitales ni pipeline CI/CD protegido incorporado |
| A09 — Logs y alertas | `Movimiento` e incidencias; `logs/seguridad.log` rotativo para login fallido y accesos denegados | Faltan monitorización centralizada y alertas en un despliegue real |
| A10 — Manejo de excepciones | `ValidationError` con mensajes aptos para el usuario, `DEBUG=0` en producción | Pruebas de fallos de BD/conexión y recuperación siguen siendo necesarias |

## Privacidad y condiciones de uso

El prototipo usa datos ficticios. Si un colegio incorpora datos personales reales, debe definir responsables, base legal aplicable en Chile, conservación, derechos de titulares, control de acceso, respaldo, políticas internas y evaluación de riesgos antes de su uso. No inferir que estas obligaciones están satisfechas solo por haber desarrollado el código.
