# Guía de evidencias para que hagas tus capturas y tu informe

La siguiente lista está basada en los requerimientos **F01–F10** del anteproyecto y en la guía de Evaluación 3. No implica que una prueba esté aprobada hasta observarse en tu computador.

| ID | Implementación actual | Qué comprobar / fotografiar |
|---|---|---|
| F01 | Login Django; vista usuarios y roles | Login de tres roles, creación/desactivación de cuenta, usuario no autorizado 403 |
| F02 | CRUD básico de Equipo, baja con historial | Inventario, agregar, editar y dar de baja un equipo sin préstamos activos |
| F03 | Catálogo filtrado por rol y calendario semanal | Alumno no ve equipo exclusivo; calendario incluye reservas reales |
| F04 | Formulario de solicitudes, estados y cancelación | Solicitud válida, cancelada, motivo y período; rechazo fuera de horario |
| F05 | Configuración Django | Cambiar horarios/duración, verificar formulario rechazado fuera de límite |
| F06 | Servicio aprobar, prioridad docente, bloqueo de conflicto | Alumno compite con profesor y gana la prioridad docente según reglas |
| F07 | Registro de entrega y condición | Administrador entrega pedido aprobado, histórico registra actor y condición |
| F08 | Devolución e incidencia abierta/resuelta | Retornar equipo, dejar incidencia, resolver y verificar movimientos |
| F09 | Detección de atraso y restricciones | Préstamo vencido bloquea cuenta; equipo prestado aparece ocupado; comando `vencer_reservas` |
| F10 | Historial, panel de reportes y CSV | Alumno solo ve lo propio, administrador consulta reportes y exporta CSV |

## Seguridad OWASP — pruebas recomendadas

- A01: Alumno envía POST a `/solicitudes/<ID>/aprobar/` y recibe **403**. No modifica estados.
- A01: Alumno intenta acceder a `/usuarios/` y `/reportes/` y recibe **403**.
- A02: revisar en DevTools → Network las cabeceras `Content-Security-Policy`, `X-Frame-Options`, `X-Content-Type-Options`.
- A05: motivo de prueba `<script>alert(1)</script>` se muestra como texto escapado, sin ejecutar JS.
- A07: tras suficientes contraseñas incorrectas desde el mismo IP recibe **429** temporal; probar en desarrollo con precaución para no bloquear el ingreso de demo.
- A07: el campo de contraseña se almacena con un hash; **no fotografiar hashes completos ni claves**.
- A06: préstamo activo impide autorizar otro préstamo de la misma unidad incluso si el plazo previo terminó.
- A09: registro `logs/seguridad.log` muestra accesos denegados e intentos de login fallidos, sin contraseñas.
- PWA: manifest, botón de instalación en Chrome/Edge local, app instalada; las acciones requieren conexión.

## Comandos para evidencia

```powershell
.\.venv\Scripts\python.exe manage.py check
.\.venv\Scripts\python.exe manage.py test prestamos
.\.venv\Scripts\python.exe manage.py vencer_reservas
```

La suite incluida contiene 13 pruebas previas y 23 pruebas nuevas: **36 casos definidos**. No marques aprobada ninguna prueba sin verificar que Django finalice con `OK` en tu computador.

## Registro sugerido por caso

- ID de caso; F/RN asociado
- Fecha y responsable de ejecución
- Cuenta de prueba, equipo y período
- Pasos ejecutados
- Resultado esperado
- Resultado realmente observado
- Estado (aprobado, fallido, bloqueado)
- Captura o ruta de evidencia
- Incidencia, corrección y ejecución posterior si hubo error
