# Turno — Arquitectura y diagramas actualizados

Estos diagramas reflejan la implementación incluida, no son capturas ni un informe académico. Se pueden visualizar como Mermaid en GitHub o en una extensión de VS Code.

## Arquitectura

```mermaid
flowchart TD
    A[Profesor / Alumno / Administrador] --> B[Navegador / PWA]
    B --> C[Vistas y formularios Django]
    C --> D[Servicios de negocio / Validaciones]
    D --> E[(Base de datos SQLite / PostgreSQL)]
    C --> F[Autenticación y sesiones Django]
    C --> G[Plantillas HTML y CSS]
    C --> H[Historial / Reportes]
    I[Comando programado vencer_reservas] --> D
```

La PWA **no** guarda solicitudes ni ejecuta operaciones offline. El servicio worker solo mantiene recursos estáticos permitidos.

## Entidades de datos

```mermaid
classDiagram
    class Usuario {
      +username
      +first_name
      +last_name
      +is_active
      +is_staff
      +password_hash
    }
    class Perfil {
      +rol: admin / prof / alum
    }
    class Equipo {
      +codigo PK
      +nombre
      +categoria
      +condicion
      +prestable
      +solo_profesores
    }
    class Solicitud {
      +id PK
      +desde
      +hasta
      +motivo
      +estado
      +incidencia_abierta
      +condicion_salida
      +condicion_retorno
    }
    class Movimiento {
      +accion
      +detalle
      +fecha
    }
    class Configuracion {
      +solicitud_desde / hasta
      +atencion_desde / hasta
      +duracion_maxima_horas
      +prioridad_docente
    }
    Usuario "1" --> "1" Perfil
    Usuario "1" --> "*" Solicitud : solicita
    Equipo "1" --> "*" Solicitud : asignación
    Solicitud "1" --> "*" Movimiento : auditoría
    Usuario "1" --> "*" Movimiento : actor
```

## Estados implementados de una solicitud

```mermaid
stateDiagram-v2
    [*] --> pendiente : profesor / alumno crea
    pendiente --> aprobada : administrador autoriza
    pendiente --> rechazada : administrador rechaza
    pendiente --> cancelada : titular / administrador cancela
    aprobada --> entregada : administrador registra entrega
    aprobada --> cancelada : titular / administrador cancela
    aprobada --> vencida : mantenimiento cuando vence período
    entregada --> cerrada : administrador registra devolución
    cerrada --> cerrada : incidencia pendiente o resuelta, en registro asociado
    rechazada --> [*]
    cancelada --> [*]
    vencida --> [*]
```

## Puntos que requieren validación práctica

- Bloqueo de doble asignación concurrente en PostgreSQL, con dos sesiones administrativas al mismo tiempo.
- Reglas definitivas de horarios del colegio; los parámetros iniciales son de demostración.
- Ejecución periódica de `vencer_reservas` configurada en Windows/servidor.
- HTTPS y copias de seguridad/restauración al desplegar; **no se asumen existentes**.
