# Turno — Backend integrado: seguridad OWASP, reportes y PWA

Esta entrega consolida el backend inicial, diseño y calendario de las 13 pruebas previas, más seguridad y pruebas nuevas. **Es código académico, no una certificación de seguridad ni un servidor publicado.** No incluye `db.sqlite3`, tu `.env`, ni tu `.venv`.

## 1. INSTALAR SIN PERDER NADA (proyecto ya funcionando)

**Muy importante:** cerrar el servidor (Ctrl+C) y abrir la terminal de VS Code en `C:\Users\blind\Downloads\turno_django`, la carpeta que ya contiene `db.sqlite3` y `.venv`.

1. **Hacer respaldo completo de la carpeta `turno_django`** (en el Explorador de Windows) antes de reemplazar código. **No borrar** `.venv`, `.env` ni `db.sqlite3`.
2. Descargar `Turno_Actualizacion_Completa_OWASP.zip` en la carpeta Descargas.
3. En PowerShell:

```powershell
cd "$HOME\Downloads\turno_django"
Copy-Item .\db.sqlite3 .\db.sqlite3.respaldo -ErrorAction SilentlyContinue
Expand-Archive -Path "$HOME\Downloads\Turno_Actualizacion_Completa_OWASP.zip" -DestinationPath . -Force
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe manage.py check
.\.venv\Scripts\python.exe manage.py test prestamos
.\.venv\Scripts\python.exe manage.py runserver
```

4. En `http://127.0.0.1:8000/`, Ctrl+F5 y entrar con tus usuarios **existentes**. Abrir: `/inventario/`, `/solicitudes/`, `/calendario/`, `/reportes/` como administrador.
5. PWA en Chrome/Edge: abrir el sitio en localhost y buscar "Instalar Turno" en menú del navegador. Una PWA no hace préstamos sin Internet: la seguridad exige validación del servidor.

**No ejecutar `cargar_demo` otra vez, ni reemplazar tu archivo `db.sqlite3` por otro.**

Si el ZIP se extrae accidentalmente como otra carpeta, **NO** ejecutes allí `.\.venv` ni `manage.py`; debes copiar el contenido al proyecto existente.

## 2. QUÉ SE IMPLEMENTÓ

- Controles de acceso de servidor por roles, incluyendo rutas directas (OWASP A01).
- Corrección de `inventario`: `rol` estaba sin definir; ocultar unidades exclusivas en catálogos de alumnos.
- CSRF de Django en formularios; cabeceras CSP, X-Frame-Options, nosniff, Referrer-Policy y Permissions-Policy (A02/A05).
- Limitación básica de intentos de inicio de sesión: 5 fallos / 15 minutos por IP; hashes de contraseña y cookies de sesión (A07).
- Protección de salida HTML mediante escape de plantillas Django y eliminación del `onsubmit` JavaScript en línea (A05).
- Validación de reglas en `services.py`; equipo físicamente prestado no admite nueva autorización, aunque su horario haya vencido (A06).
- Registro de movimientos y archivo rotativo `logs/seguridad.log` para intentos fallidos y límites de acceso (A09).
- PWA instalable en navegadores compatibles: manifest 192/512, servicio `/sw.js` con caché exclusivamente de CSS/iconos. **Nunca** se guardan páginas privadas ni respuestas de formularios sin conexión.
- Administración de cuentas (`/usuarios/`): crear, editar roles, desactivar y cambiar contraseñas preservando historial.
- Reportes de administrador (`/reportes/`) y exportación CSV protegida contra fórmulas (`/reportes/csv/`).
- Automatización de reservas vencidas (`python manage.py vencer_reservas`).
- Pruebas adicionales en `prestamos/test_seguridad.py`. **Debes ejecutarlas en tu computador.**

## 3. AUTOMATIZAR EL VENCIMIENTO

La reserva aprobada sin retiro se libera cuando pasó su fecha final, pero **el comando debe programarse**. Prueba manualmente:

```powershell
.\.venv\Scripts\python.exe manage.py vencer_reservas
```

Para producción/piloto usa Programador de tareas de Windows y ejecuta `powershell.exe -NoProfile -ExecutionPolicy Bypass -File "RUTA_ABSOLUTA\turno_django\scripts\MANTENIMIENTO_WINDOWS.ps1"` cada 5–15 minutos. Verifica permisos del usuario de Windows y logs de tareas. El calendario no ejecuta mantenimientos en segundo plano.

## 4. POSTGRESQL: LISTO PARA CONECTAR, REQUIERE MIGRAR TUS DATOS

La configuración inicial se mantiene en SQLite **para no borrar ni ocultar tus préstamos existentes**. Para activar PostgreSQL de verdad:

1. Respalda primero: `powershell -ExecutionPolicy Bypass -File .\scripts\RESPALDAR_WINDOWS.ps1`.
2. Instala PostgreSQL servidor en Windows y crea, con un usuario administrador PostgreSQL, una BD `turno_db` y un usuario específico `turno` con permisos solo sobre esa BD.
3. Instala driver: `.\.venv\Scripts\python.exe -m pip install -r requirements-postgres.txt`.
4. Crea una copia de `.env` y edita solamente las variables `DB_ENGINE=postgres`, `DB_NAME`, `DB_USER`, `DB_PASSWORD`, `DB_HOST`, `DB_PORT`.
5. Aplica esquema: `.\.venv\Scripts\python.exe manage.py migrate`.
6. En una base nueva y vacía importa el JSON respaldado: `.\.venv\Scripts\python.exe manage.py loaddata backups\NOMBRE_DE_TU_RESPALDO.json`.
7. Verifica recuentos, cuentas, inventario, historial y al menos un flujo completo. Ejecuta pruebas automatizadas (Django crea una BD de prueba separada). Si falla, restaura `.env` al SQLite anterior **sin borrar ese archivo**.

El JSON contiene cuentas y hashes de contraseñas, así que debes protegerlo, evitar enviarlo por chat y borrarlo de lugares compartidos. Para datos reales y operación en producción usa backups PostgreSQL cifrados y restauración probada.

## 5. PUBLICAR DE MANERA SEGURA (NO ES SOLO DEBUG=0)

En un servidor HTTPS: genera `SECRET_KEY` robusta, pon `DEBUG=0`, dominio real en `ALLOWED_HOSTS`, origen `https://...` en `CSRF_TRUSTED_ORIGINS`, certificado TLS y servidor ASGI/WSGI (no `runserver`). Configura HTTPS para que `SESSION_COOKIE_SECURE`, `CSRF_COOKIE_SECURE`, HSTS y redirect funcionen; revisa `manage.py check --deploy`. HSTS de subdominios o preload deben activarse solo tras verificar todos los subdominios. **No actives `TRUST_PROXY_SSL_HEADER=1` salvo que el proxy confiable establezca la cabecera y elimine cualquiera suministrada por usuarios.**

El limitador utiliza caché local por defecto; **para múltiples procesos en producción necesitarás una caché compartida (Redis/Memcached) o WAF**. No es defensa absoluta ante ataques distribuidos. La PWA requiere HTTPS público o localhost para instalarse. Para producción también hay que definir servidor de estáticos, monitorización, copias de seguridad y permisos de acceso a los registros.

Genera una clave local nueva usando (sin mostrar ni compartir su valor):

```powershell
.\.venv\Scripts\python.exe -c "from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())"
```

Coloca el resultado en tu `.env` existente **sin subirlo a repositorios**. Si cambias la clave, las sesiones previas pueden cerrarse y requerir nuevo inicio de sesión.

## 6. EVIDENCIA PARA LA EVALUACIÓN 3 (las capturas las tomas tú)

- Inicio de sesión por los tres roles; denegación de acceso no autorizado.
- Vista de inventario y equipo exclusivo oculto para el alumno.
- Caso positivo crear → aprobar → entregar → devolver, y su historial.
- Caso negativo: alumno intenta aprobar por URL directa (403).
- Conflictos de fecha, prioridad docente, atrasos, incidencias y reserva vencida. Comprobar que un equipo entregado que está atrasado se muestra ocupado en el calendario futuro.
- Calendario y PWA instalable en Chrome/Edge con localhost.
- Reportes y CSV del administrador, bloqueados para alumnos.
- Terminal con `manage.py check`, `manage.py test prestamos`, `manage.py check --deploy` (este último solo con configuración de despliegue y HTTPS reales).
- No incluyas contraseñas, claves, tokens o datos personales reales en capturas.

## 7. LÍMITES REALES

- No hay sincronización offline ni apps Android/iOS nativas (excluidas por el anteproyecto).
- La migración PostgreSQL, despliegue HTTPS, backups en servidor y Programador de tareas requieren tu computador e infraestructura; el ZIP no puede completar esas acciones automáticamente.
- La simultaneidad real de dos administradores debe probarse especialmente usando PostgreSQL: SQLite no ofrece el mismo comportamiento de bloqueo de filas.
- Si el colegio usa datos de estudiantes reales, requiere medidas institucionales y revisión jurídica/operativa adicional antes de usarlo en producción.
- Las pruebas y cobertura de seguridad son un punto de partida, no un pentest ni una garantía de ausencia de vulnerabilidades.

## 8. DOCUMENTACIÓN TÉCNICA COMPLEMENTARIA

- `docs/ARQUITECTURA_Y_UML.md`: diagramas del sistema con Mermaid.
- `docs/CHECKLIST_EVIDENCIA_TECNICA.md`: casos para capturar con datos ficticios.
- `docs/CONTROLES_OWASP.md`: correspondencia entre código y riesgos OWASP Top 10:2025, con limitaciones.
